// Função para filtrar e exibir os produtos que começam com o termo de pesquisa
function showFilteredProducts(searchTerm) {
    const productResultsContainer = document.getElementById('productResults');
    productResultsContainer.innerHTML = '';

    // Filtra os produtos que começam com o termo de pesquisa (ignora maiúsculas/minúsculas)
    const matchingProducts = productData.filter(product =>
        product.nome.toLowerCase().startsWith(searchTerm.toLowerCase())
    );

    // Exibe os produtos filtrados
    if (matchingProducts.length > 0) {
        matchingProducts.forEach(product => {
            const productElement = document.createElement('div');
            productElement.className = 'product-item';
            productElement.innerHTML = `
                <h3>${product.nome}</h3>
                <p>Preço: R$ ${product.preco.toFixed(2)}</p>
            `;
            productResultsContainer.appendChild(productElement);
        });
    } else {
        // Mensagem caso nenhum produto seja encontrado
        productResultsContainer.innerHTML = '<p>Nenhum produto encontrado.</p>';
    }
}

// Evento de entrada no campo de pesquisa
document.getElementById('productSearchInput').addEventListener('input', function() {
    const searchTerm = this.value;
    showFilteredProducts(searchTerm);
});

// Fecha o modal quando o botão "Entendi" é clicado
document.getElementById('closeModalButton').addEventListener('click', function() {
    document.getElementById('modalMessage').style.display = 'none';
});
