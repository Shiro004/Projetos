document.getElementById('searchButton').addEventListener('click', fetchCityByCEP);

async function fetchCityByCEP() {
    const cepInput = document.getElementById('cepInputField').value.trim();
    const resultDisplay = document.getElementById('cityResult');

    resultDisplay.textContent = '';
    resultDisplay.style.color = '#333';

    const isValidCEP = /^\d{5}-?\d{3}$/.test(cepInput);
    if (!isValidCEP) {
        resultDisplay.textContent = 'CEP inválido. Digite no formato 12345-678.';
        resultDisplay.style.color = 'red';
        return;
    }

    try {
        const response = await fetch(`https://viacep.com.br/ws/${cepInput}/json/`);
        const data = await response.json();

        if (data.erro) {
            resultDisplay.textContent = 'CEP não encontrado.';
            resultDisplay.style.color = 'red';
        } else {
            resultDisplay.textContent = `Cidade: ${data.localidade}`;
            resultDisplay.style.color = '#333';
        }
    } catch (error) {
        resultDisplay.textContent = 'Erro ao consultar o CEP. Verifique sua conexão e tente novamente.';
        resultDisplay.style.color = 'red';
        console.error('Erro ao buscar CEP:', error);
    }
}
