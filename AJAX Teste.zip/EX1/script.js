// Adiciona um evento para permitir a busca ao pressionar a tecla Enter
document.getElementById('inputNomeUsuario').addEventListener('keypress', function (evento) {
    if (evento.key === 'Enter') {
        executarBusca();
    }
});

async function executarBusca() {
    const termoPesquisa = document.getElementById('inputNomeUsuario').value.toLowerCase();
    const listaUsuariosElemento = document.getElementById('listaUsuarios');
    listaUsuariosElemento.innerHTML = '';

    try {
        const resposta = await fetch('https://jsonplaceholder.typicode.com/users');
        const usuarios = await resposta.json();

        const usuariosFiltrados = usuarios.filter(usuario => 
            usuario.name.toLowerCase().includes(termoPesquisa)
        );

        usuariosFiltrados.forEach(usuario => {
            const itemLista = document.createElement('li');
            itemLista.innerHTML = `
                <span class="user-info">${usuario.name}</span> 
                <div class="user-details">Usuário: ${usuario.username} | Email: ${usuario.email}</div>
            `;
            listaUsuariosElemento.appendChild(itemLista);
        });

        if (usuariosFiltrados.length === 0) {
            const itemLista = document.createElement('li');
            itemLista.textContent = 'Nenhum usuário encontrado';
            listaUsuariosElemento.appendChild(itemLista);
        }
    } catch (erro) {
        console.error('Erro ao buscar usuários:', erro);
    }
}
