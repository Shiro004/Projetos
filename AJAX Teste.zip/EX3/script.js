document.getElementById('dataSaveForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const inputData = document.getElementById('dataInput').value;

    const textBlob = new Blob([inputData], { type: 'text/plain' });

    const downloadURL = URL.createObjectURL(textBlob);

    const downloadLink = document.createElement('a');
    downloadLink.href = downloadURL;
    downloadLink.download = 'dados.txt';
    downloadLink.click();

    URL.revokeObjectURL(downloadURL);
});
