document.addEventListener('DOMContentLoaded', function() {
    const nameInput = document.getElementById('nameInput');
    const nameListItems = document.querySelectorAll('#nameList li');

    function destacarNomes() {
        const inputValue = nameInput.value.toLowerCase();

        nameListItems.forEach(function(item) {
            const nome = item.textContent.toLowerCase();
            
            if (nome.startsWith(inputValue) && inputValue !== '') {
                item.innerHTML = `<b>${item.textContent}</b>`;
            } else {
                item.innerHTML = item.textContent;
            }
        });
    }

    nameInput.addEventListener('input', destacarNomes);
});
