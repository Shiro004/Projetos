document.addEventListener('DOMContentLoaded', function() {
    const alunoForm = document.getElementById('alunoForm');
    const alunoList = document.getElementById('alunoList');

    alunoForm.addEventListener('submit', function(event) {
        event.preventDefault();

        const nome = document.getElementById('nome').value;

        // Captura e permite tanto vírgulas quanto pontos para os valores das notas
        const nota1 = parseFloat(document.getElementById('nota1').value.replace(',', '.'));
        const nota2 = parseFloat(document.getElementById('nota2').value.replace(',', '.'));
        const nota3 = parseFloat(document.getElementById('nota3').value.replace(',', '.'));

        // Verifica se os valores são números válidos
        if (isNaN(nota1) || isNaN(nota2) || isNaN(nota3)) {
            alert('Por favor, insira valores válidos para as notas.');
            return;
        }

        // Calcula a média
        const media = ((nota1 + nota2 + nota3) / 3).toFixed(2);

        const li = document.createElement('li');
        li.innerHTML = `Nome: ${nome} - Média: ${media} 
                        <button class="remove-btn">Remover</button>`;

        // Botão de remover aluno
        li.querySelector('.remove-btn').addEventListener('click', function() {
            li.remove();
        });

        alunoList.appendChild(li);

        // Limpar o formulário
        alunoForm.reset();
    });
});
