document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('inscriptionForm');
    const confirmationMessage = document.getElementById('confirmationMessage');

    form.addEventListener('submit', function(event) {
        event.preventDefault(); // Impede o envio do formulário

        const name = document.getElementById('name').value;
        const email = document.getElementById('email').value;
        const workshop = document.getElementById('workshop').value;
        const updates = document.getElementById('updates').checked;

        let message = `Obrigado, ${name}, por se inscrever no workshop de ${workshop}.`;

        if (updates) {
            message += " Você receberá atualizações por email.";
        }

        confirmationMessage.textContent = message;
    });
});
