document.addEventListener('DOMContentLoaded', function() {
    const cadastroForm = document.getElementById('cadastroForm');
    const cadastroList = document.getElementById('cadastroList');
    const textoDigitadoDiv = document.getElementById('textoDigitado');
    const salvarCheckbox = document.getElementById('salvar');

    cadastroForm.addEventListener('submit', function(event) {
        event.preventDefault(); // Impede o envio do formulário

        const nome = document.getElementById('nome').value;
        const email = document.getElementById('email').value;
        const salvar = salvarCheckbox.checked;

        // Exibe o texto digitado na div 'textoDigitado'
        textoDigitadoDiv.textContent = `Nome: ${nome}, Email: ${email}`;

        // Se o usuário quiser salvar, adiciona à lista de usuários salvos
        if (salvar) {
            const li = document.createElement('li');
            li.textContent = `Nome: ${nome}, Email: ${email}`;
            cadastroList.appendChild(li);
        }

        // Limpar os campos após o envio
        cadastroForm.reset();
    });
});
