document.addEventListener('DOMContentLoaded', function() {
    const productInput = document.getElementById('productInput');
    const productListItems = document.querySelectorAll('#productList li');

    function filtrarProdutos() {
        const inputValue = productInput.value.toLowerCase();

        productListItems.forEach(function(item) {
            const produto = item.textContent.toLowerCase();

            if (produto.includes(inputValue)) {
                item.style.display = 'list-item'; // Mostra o item
            } else {
                item.style.display = 'none'; // Oculta o item
            }
        });
    }

    productInput.addEventListener('input', filtrarProdutos);
});
