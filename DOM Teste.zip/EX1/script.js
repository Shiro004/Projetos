document.addEventListener('DOMContentLoaded', function() {
    const inputNumber = document.getElementById('number');
    const resultDiv = document.getElementById('result');

    function gerarTabuada() {
        const num = parseInt(inputNumber.value);
        resultDiv.innerHTML = ''; // Limpa o conteúdo anterior

        if (!isNaN(num) && num !== 0) {
            const titulo = document.createElement('strong');
            titulo.innerText = `Tabuada do ${num}`;
            resultDiv.appendChild(titulo);

            for (let i = 1; i <= 10; i++) {
                const linha = document.createElement('p');
                linha.innerText = `${num} x ${i} = ${num * i}`;
                resultDiv.appendChild(linha);
            }
        }
    }

    // Adiciona o listener para o evento input
    inputNumber.addEventListener('input', gerarTabuada);
});
